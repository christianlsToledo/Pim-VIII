//------------------------------------------------------------------------------
// <gerado automaticamente>
//     Este c�digo foi gerado por uma ferramenta.
//
//     As altera��es ao arquivo poder�o causar comportamento incorreto e ser�o perdidas se
//     o c�digo for recriado
// </gerado automaticamente>
//------------------------------------------------------------------------------

namespace PimVIII {
    
    
    public partial class ViewSwitcher {
    }
}
