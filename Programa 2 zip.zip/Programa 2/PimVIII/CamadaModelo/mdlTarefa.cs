﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;


namespace CamadaModelo
{
    public class mdlTareefa
    {
        public int idTarefa { get; set; }
        public string nomeTarefa { get; set; }
        public string Descricao { get; set; }
        public string dataEntrega { get; set; }
      }
}
