﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using CamadaModelo;
using System.Configuration.Assemblies;
using System.Configuration;

namespace CamadaControle
{
    public class ctlTareefa

    {
        public bool Cadastrar(mdlTareefa _mdlTareefa)
        {
            try
            {
                string conexaoAccess = ConfigurationManager.ConnectionStrings["conexaoAccess"].ToString();               
                OleDbConnection conexaodb = new OleDbConnection(conexaoAccess);
                conexaodb.Open();

                string query = "INSERT INTO tarefa (nomeTarefa, Descricao, dataEntrega) VALEUS (@nomeTarefa, @descricao, @dataEntrega)";
                OleDbCommand cmd = new OleDbCommand(query, conexaodb);

                var pmtnomeTarefa = cmd.CreateParameter();
                pmtnomeTarefa.ParameterName = "@nomeTarefa";
                pmtnomeTarefa.DbType = DbType.String;
                pmtnomeTarefa.Value = _mdlTareefa.nomeTarefa;
                cmd.Parameters.Add(pmtnomeTarefa);

                var pmtDescricao = cmd.CreateParameter();
                pmtDescricao.ParameterName = "@descricao";
                pmtDescricao.DbType = DbType.String;
                pmtDescricao.Value = _mdlTareefa.Descricao;
                cmd.Parameters.Add(pmtDescricao);

                var pmtdataEntrega = cmd.CreateParameter();
                pmtdataEntrega.ParameterName = "@dataEntrega";
                pmtdataEntrega.DbType = DbType.String;
                pmtdataEntrega.Value = _mdlTareefa.dataEntrega;
                cmd.Parameters.Add(pmtdataEntrega);

            
               // if (cmd.ExecuteNonQuery() > 0)
                {
                    conexaodb.Close();
                    return true;
                }//       return true;        

            }
            catch (Exception ex)
            {
                throw ex;             
            }
        }
    }
}
