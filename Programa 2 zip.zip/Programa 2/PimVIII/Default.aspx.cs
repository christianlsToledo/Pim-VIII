﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CamadaControle;           //Importar Camadas
using CamadaModelo;             //Importar Camadas
using System.Configuration;
using System.Data.OleDb;

namespace PimVIII
{
    public partial class _Default : Page
    {

        void Page_Load(object sender, EventArgs e)
        {

        }    

        protected void Cadastrar_Click(object sender, EventArgs e)
        {
            ctlTareefa _ctlTareefa = new ctlTareefa();
            mdlTareefa _mdlTareefa = new mdlTareefa();            

            _mdlTareefa.nomeTarefa = txtnome.Text;
            _mdlTareefa.Descricao = txtDescricao.Text;
            _mdlTareefa.dataEntrega = txtdataEntrega.Text;


            bool retornoInsert = _ctlTareefa.Cadastrar(_mdlTareefa);

            if (retornoInsert == true)
            {
                ScriptManager.RegisterStartupScript(this,
                                                    this.GetType(),
                                                    "Secesso",
                                                    "alert('Tarefa salva com Sucesso !');",
                                                    true);
            }else
            {
                ScriptManager.RegisterStartupScript(this,
                                                    this.GetType(),
                                                    "Secesso",
                                                    "alert('Erro oa salvar !');",
                                                    true);
            }
        }
    }
}